<?php
    define('PATH','10.72.160.15');
    define('DBNAME','intranet');
    define('USER','root');
    define('PASS','interpublicIU');
?>
