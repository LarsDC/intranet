<h1 class="header">EXTERNAL LINKS</h1>
<h4 class="externallinks">Opens on a new browser tab</h4>
<div class="linkbox">
    <table class="extlinks">
    <tr>
        <td><a href="http://in-countryss.interpublic.com/Nordic/Tickets/AdminTickets.aspx" class="extlinks" title="NBO Ticket System / Helpdesk" target="blank">Nordic Back Office</a></td>
        <td><a href="http://sps.mbww.com/sites/mbg-emea/nordics/DK/Interne%20Procedurer" class="extlinks" title="Interne Procedurer" target="blank">Interne Procedurer</a></td>
        <td><a href="http://insider.initiative.com/" class="extlinks" title="Insider" target="blank">Insider</a></td>
        <td><a href="http://intranet.ium.dk/tools/Marathon.bat" class="extlinks" title="" target="blank">Marathon</a></td>
    </tr>
    <tr>
        <td><a href="http://snapshot.iumnordic.com/" class="extlinks" title="" target="blank">Snapshot</a></td>
        <td><a href="http://zebra.iumnordic.com/" class="extlinks" title="" target="blank">Zebra</a></td>
        <td><a href="http://extranet.iumnordic.com/" class="extlinks" title="" target="blank">Extranet</a></td>
        <td><a href="https://webcargo.net/ipg" class="extlinks" title="" target="blank">Webcargo</a></td>
    </tr>
    <tr>
        <td></td>
        <td><a href="http://intranet.umww.com/limo/" class="extlinks" title="" target="blank">Limo</a></td>
        <td><a href="http://www.mediabrandsww.com/worldmarkets/" class="extlinks" title="" target="blank">MB World Markets</a></td>
        <td></td>
    </tr> 
    </table>
</div>