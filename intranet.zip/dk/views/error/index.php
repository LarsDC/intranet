<?php
echo 'error page!';
echo $this->msg;
?>
