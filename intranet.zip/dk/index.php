<?php

    require 'libs/Bootstrap.php';
    require 'libs/Controller.php';
    require 'libs/Model.php';
    require 'libs/View.php';

    
    require 'libs/database.php';
    
    require 'config/paths.php';
    require 'config/database.php';
    ini_set('display_errors', 0);
    $app = new Bootstrap();
?>
