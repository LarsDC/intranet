<?php

class Help extends Controller{

    function __construct() {
        parent::__construct();
    }
    
    public function other(){
        echo 'we are inside other';
    }

}
?>
