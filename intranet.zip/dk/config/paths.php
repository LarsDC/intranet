<?php
    //DOMAINS
    //define('URL_DK', 'http://localhost/dk/');
    define('URL_DK', 'http://wiki.ium.dk/dk/');
    define('URL_FI', 'http://localhost/fi/');
    define('URL_NO', 'http://localhost/no/');
    define('URL_SE', 'http://localhost/se/');
    //define('URL', 'http://localhost/');
    define('URL', 'http://wiki.ium.dk/');
    
    //XML NAMES
    define('DK_FRONTBOX', "http://www.frontbox.dk/rss2");
    define('DK_MEDIAWATCH','http://mediawatch.dk/rss.xml');
    define('DK_CALENDAR', URL_DK.'public/xml/calendar.xml');
    define('DK_FRONTBOX_FILE','http://localhost/dk/public/xml/frontbox.xml');
    //define('DK_MEDIAWATCH_FILE','http://localhost/dk/public/xml/mediawatch.xml');
    define('DK_MEDIAWATCH_FILE','http://wiki.ium.dk/dk/public/xml/mediawatch.xml');
?>
