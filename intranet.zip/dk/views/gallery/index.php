<h1 class="header">GALLERY </h1>
<h4 class="externallinks">Links opens on a new browser tab</h4>
<?php

include('embeddedGallery.php');
?>